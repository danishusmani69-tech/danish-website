import Navbar from './Navbar';
import Footer from './Footer';

export default function PageWrapper({ children }: { children: React.ReactNode }) {
  return <><Navbar />{children}<Footer /></>;
}
