import Link from 'next/link';
import { navigation } from '@/lib/navigation';
import { siteConfig } from '@/lib/site-config';

export default function Footer() {
  return (
    <footer className="border-t border-line py-12 text-sm text-muted">
      <div className="container flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
        <div><span className="text-gold">DU</span> © 2026 Danish Usmani</div>
        <div className="flex flex-wrap gap-5">
          {navigation.map((item) => <Link key={item.href} href={item.href} className="hover:text-gold">{item.label}</Link>)}
          <a href={`mailto:${siteConfig.email}`} className="hover:text-gold">Email</a>
        </div>
      </div>
    </footer>
  );
}
