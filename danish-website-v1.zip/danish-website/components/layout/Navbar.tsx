'use client';
import Link from 'next/link';
import { useState } from 'react';
import { navigation } from '@/lib/navigation';

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed top-0 z-50 w-full border-b border-line/70 bg-ink/70 backdrop-blur-xl">
      <div className="container flex h-20 items-center justify-between">
        <Link href="/" className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-sm font-semibold text-gold">DU</Link>
        <nav className="hidden items-center gap-8 text-sm text-muted md:flex">
          {navigation.map((item) => <Link key={item.href} href={item.href} className="transition hover:text-gold">{item.label}</Link>)}
        </nav>
        <button onClick={() => setOpen(!open)} className="md:hidden text-gold">Menu</button>
      </div>
      {open && (
        <div className="container pb-8 md:hidden">
          <div className="grid gap-5 text-3xl serif">
            {navigation.map((item) => <Link key={item.href} href={item.href} onClick={() => setOpen(false)}>{item.label}</Link>)}
          </div>
        </div>
      )}
    </header>
  );
}
