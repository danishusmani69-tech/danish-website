import Link from 'next/link';

type Props = { category: string; title: string; summary: string; time: string; href?: string };
export default function InsightRow({ category, title, summary, time, href = '/insights' }: Props) {
  return (
    <Link href={href} className="group grid gap-5 border-t border-line py-10 md:grid-cols-[.25fr_1fr_.2fr] md:items-start">
      <div className="label">{category}</div>
      <div>
        <h3 className="serif text-3xl tracking-[-.04em] transition group-hover:text-gold md:text-5xl">{title}</h3>
        <p className="body mt-4 max-w-2xl">{summary}</p>
      </div>
      <div className="text-sm text-muted md:text-right">{time}</div>
    </Link>
  );
}
