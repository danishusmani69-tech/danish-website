import Link from 'next/link';

type Props = {
  label?: string;
  headline: string;
  copy: string;
  primary?: { label: string; href: string };
  secondary?: { label: string; href: string };
};

export default function EditorialHero({ label, headline, copy, primary, secondary }: Props) {
  return (
    <section className="hero-section">
      <div className="container grid items-center gap-14 lg:grid-cols-[1.08fr_.92fr]">
        <div>
          {label && <div className="label mb-8">{label}</div>}
          <h1 className="display h1 max-w-5xl">{headline}</h1>
          <p className="body-large mt-8 max-w-2xl">{copy}</p>
          <div className="mt-10 flex flex-wrap gap-4">
            {primary && <Link className="btn btn-gold" href={primary.href}>{primary.label}</Link>}
            {secondary && <Link className="btn" href={secondary.href}>{secondary.label}</Link>}
          </div>
        </div>
        <div className="visual-orb grid-line" aria-hidden="true" />
      </div>
    </section>
  );
}
