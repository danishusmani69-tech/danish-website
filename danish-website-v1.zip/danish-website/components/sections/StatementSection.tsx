type Props = { label?: string; headline: string; copy?: string; closing?: string };
export default function StatementSection({ label, headline, copy, closing }: Props) {
  return (
    <section className="section">
      <div className="container max-w-5xl">
        {label && <div className="label mb-7">{label}</div>}
        <h2 className="display h2">{headline}</h2>
        {copy && <p className="body-large mt-8 max-w-3xl">{copy}</p>}
        {closing && <p className="serif mt-10 text-3xl text-gold md:text-5xl">{closing}</p>}
      </div>
    </section>
  );
}
