import Link from 'next/link';

type Props = { number: string; title: string; copy: string; metric?: string; href?: string };
export default function ExecutionBlock({ number, title, copy, metric, href = '/execution' }: Props) {
  return (
    <Link href={href} className="editorial-card block p-8 md:p-12">
      <div className="label">{number}</div>
      <div className="mt-16 grid gap-8 md:grid-cols-[1fr_.9fr] md:items-end">
        <h3 className="display h3">{title}</h3>
        <div>
          {metric && <div className="serif mb-5 text-5xl text-gold">{metric}</div>}
          <p className="body">{copy}</p>
        </div>
      </div>
    </Link>
  );
}
