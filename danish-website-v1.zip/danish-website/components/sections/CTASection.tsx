import Link from 'next/link';

type Props = { headline: string; copy: string; primary: { label: string; href: string }; secondary?: { label: string; href: string } };
export default function CTASection({ headline, copy, primary, secondary }: Props) {
  return (
    <section className="section text-center">
      <div className="container max-w-4xl">
        <h2 className="display h2">{headline}</h2>
        <p className="body-large mx-auto mt-8 max-w-2xl">{copy}</p>
        <div className="mt-10 flex justify-center gap-4 flex-wrap">
          <Link className="btn btn-gold" href={primary.href}>{primary.label}</Link>
          {secondary && <Link className="btn" href={secondary.href}>{secondary.label}</Link>}
        </div>
      </div>
    </section>
  );
}
