'use client';
import { useState } from 'react';

export default function ContactForm() {
  const [sent, setSent] = useState(false);
  return (
    <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="mx-auto max-w-3xl space-y-5">
      {['Name','Email','Organization'].map((field) => (
        <input key={field} required placeholder={field} className="w-full border-b border-line bg-transparent px-1 py-5 text-ivory outline-none transition focus:border-gold" />
      ))}
      <textarea required placeholder="What are you navigating?" rows={5} className="w-full resize-none border-b border-line bg-transparent px-1 py-5 text-ivory outline-none transition focus:border-gold" />
      <button className="btn btn-gold" type="submit">Begin Conversation</button>
      {sent && <p className="text-gold">Received. I’ll get back to you soon.</p>}
    </form>
  );
}
