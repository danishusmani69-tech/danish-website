export const siteConfig = {
  name: 'Danish Usmani',
  initials: 'DU',
  email: 'danishwanish123@gmail.com',
  linkedin: 'https://www.linkedin.com/',
  description: 'Strategic AI systems operator helping businesses turn operational chaos into scalable AI-powered systems.'
};
