export const navigation = [
  { label: 'Approach', href: '/approach' },
  { label: 'Execution', href: '/execution' },
  { label: 'Insights', href: '/insights' },
  { label: 'About', href: '/about' },
  { label: 'Contact', href: '/contact' }
];
