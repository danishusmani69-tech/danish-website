# Danish Usmani Website

Premium editorial personal website for Danish Usmani.

## Stack
- Next.js
- Tailwind CSS
- Framer Motion-ready architecture
- Static export for Cloudflare Pages

## Run locally
```bash
npm install
npm run dev
```

## Build for Cloudflare Pages
```bash
npm run build
```

The static output will be generated in `/out` because `next.config.mjs` uses `output: 'export'`.

## Final pages
- Home
- Approach
- Execution
- Insights
- About
- Contact

No Credibility page is included. Discarded dense sections are intentionally excluded.
