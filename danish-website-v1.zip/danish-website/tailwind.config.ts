import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx,mdx}', './components/**/*.{js,ts,jsx,tsx,mdx}', './content/**/*.{mdx}'],
  theme: {
    extend: {
      colors: {
        ink: '#080807',
        charcoal: '#141412',
        gold: '#d7b46a',
        ivory: '#f4efe3',
        muted: '#a19a8d',
        line: 'rgba(244,239,227,0.13)'
      },
      fontFamily: {
        serif: ['Georgia', 'Cormorant Garamond', 'serif'],
        sans: ['Inter', 'ui-sans-serif', 'system-ui']
      },
      transitionTimingFunction: {
        premium: 'cubic-bezier(.2,.8,.2,1)'
      }
    }
  },
  plugins: []
};
export default config;
