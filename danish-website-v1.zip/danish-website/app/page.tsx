import PageWrapper from '@/components/layout/PageWrapper';
import EditorialHero from '@/components/sections/EditorialHero';
import StatementSection from '@/components/sections/StatementSection';
import ExecutionBlock from '@/components/sections/ExecutionBlock';
import CTASection from '@/components/sections/CTASection';

export default function Home() {
  return <PageWrapper>
    <EditorialHero label="AI Product • Systems • Operations" headline="Turning operational chaos into scalable AI-powered systems." copy="I work with startups and businesses to redesign workflows, product operations, and execution systems using AI, automation, and structured operational thinking." primary={{label:'Start a Strategic Conversation', href:'/contact'}} secondary={{label:'Explore Execution', href:'/execution'}} />
    <StatementSection label="Systems Problem" headline="Most operational problems are not caused by lack of effort. They are caused by fragmented systems." copy="Disconnected tools, scattered knowledge, unclear workflows, and operational bottlenecks compound as organizations scale — even after adopting modern AI tools." />
    <section className="section"><div className="container space-y-8">
      <ExecutionBlock number="01" title="Agentic Workflow Systems" copy="Co-built orchestration environments enabling structured multi-step execution, visibility layers, validation checkpoints, and safe operational automation." />
      <ExecutionBlock number="02" title="Enterprise Product Scaling" metric="100+" copy="Scaled enterprise SaaS products across complex operational environments while aligning execution with business outcomes and customer adoption." />
      <ExecutionBlock number="03" title="Operational Transformation" metric="100%" copy="Led operational and organizational transformation initiatives focused on execution clarity, scalable coordination, and measurable business impact." />
    </div></section>
    <StatementSection headline="AI alone does not create leverage. Systems do." copy="The goal is not to add more tools. The goal is to create operational environments where workflows, people, knowledge, and execution move together with clarity." />
    <CTASection headline="Good systems reduce friction. Great systems create leverage." copy="If you are navigating operational complexity, workflow fragmentation, or AI transition challenges — let’s design systems built for clarity and scale." primary={{label:'Start a Strategic Conversation', href:'/contact'}} secondary={{label:'View Insights', href:'/insights'}} />
  </PageWrapper>;
}
