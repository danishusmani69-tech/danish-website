'use client';
import { useState } from 'react';
import PageWrapper from '@/components/layout/PageWrapper';
import EditorialHero from '@/components/sections/EditorialHero';
import StatementSection from '@/components/sections/StatementSection';
import InsightRow from '@/components/sections/InsightRow';
import CTASection from '@/components/sections/CTASection';

const insights = [
  { category: 'AI Systems', title: 'Why AI adoption fails inside fragmented operational systems.', summary: 'Most AI initiatives struggle not because models are weak — but because workflows, visibility, ownership, and coordination remain fragmented.', time: '4 min' },
  { category: 'Operational Leverage', title: 'Operational leverage vs operational intensity.', summary: 'The strongest teams do not simply work harder. They design environments where effort compounds more cleanly.', time: '3 min' },
  { category: 'Decision Systems', title: 'Systems visibility is an underrated competitive advantage.', summary: 'When leaders see work clearly, they make fewer reactive decisions and create more predictable execution environments.', time: '5 min' },
  { category: 'Workflow Architecture', title: 'AI systems need governance, not just automation.', summary: 'Automation without validation, visibility, and rollback creates risk faster than it creates leverage.', time: '4 min' }
];
const categories = ['All','AI Systems','Operational Leverage','Product Thinking','Workflow Architecture','Scaling Complexity','Decision Systems'];

export default function Insights() {
  const [active, setActive] = useState('All');
  const filtered = active === 'All' ? insights : insights.filter(i => i.category === active);
  return <PageWrapper>
    <EditorialHero label="Insights" headline="Most organizations do not fail because of lack of ambition. They fail because complexity compounds silently." copy="Thoughts on systems design, operational leverage, AI-native execution, product strategy, and scaling clarity inside complex environments." primary={{label:'Explore Insights', href:'#insight-feed'}} secondary={{label:'View Approach', href:'/approach'}} />
    <StatementSection headline="Why AI adoption fails inside fragmented operational systems." copy="Most AI initiatives struggle not because models are weak — but because workflows, visibility, ownership, and operational coordination remain fragmented." />
    <section className="section"><div className="container">
      <div className="label mb-8">Thinking Domains</div>
      <div className="flex flex-wrap gap-3">{categories.map(c=><button key={c} onClick={()=>setActive(c)} className={`btn ${active===c?'btn-gold':''}`}>{c}</button>)}</div>
    </div></section>
    <section id="insight-feed" className="section"><div className="container">
      {filtered.map(i => <InsightRow key={i.title} {...i} />)}
    </div></section>
    <StatementSection headline="Technology scales faster than organizational clarity." copy="The future advantage of organizations will not come from adopting more tools. It will come from designing environments where systems, workflows, and decision-making remain coherent under scale." />
    <CTASection headline="Well-designed systems create clarity before they create speed." copy="The strongest operational environments often feel quieter, simpler, and more intentional than expected." primary={{label:'Start a Strategic Conversation', href:'/contact'}} secondary={{label:'View Execution', href:'/execution'}} />
  </PageWrapper>;
}
