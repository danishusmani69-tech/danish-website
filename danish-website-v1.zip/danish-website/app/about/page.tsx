import PageWrapper from '@/components/layout/PageWrapper';
import EditorialHero from '@/components/sections/EditorialHero';
import StatementSection from '@/components/sections/StatementSection';
import CTASection from '@/components/sections/CTASection';

export default function About() {
  const themes = ['Enterprise product environments','SaaS platform scaling','Workflow-intensive systems','AI-native operational environments','Product and operational leadership','Founder and consulting experiences'];
  const principles = ['Systems before intensity','Clarity before scale','Leverage before complexity','Execution before theater'];
  return <PageWrapper>
    <EditorialHero label="About" headline="I have always been more interested in systems than surfaces." copy="Across product leadership, operational environments, AI systems, and consulting work, the consistent focus has been understanding how complexity emerges — and how clarity can be designed intentionally." primary={{label:'View Approach', href:'/approach'}} secondary={{label:'Explore Execution', href:'/execution'}} />
    <StatementSection headline="Most operational problems are symptoms of deeper structural misalignment." copy="Over time, I became less interested in isolated tasks and more interested in how workflows, systems, communication, decision-making, and execution environments interact under scale and pressure." closing="Clarity is rarely accidental. It is usually designed." />
    <section className="section"><div className="container">
      <div className="label mb-12">Journey Through Systems & Product</div>
      <div className="grid gap-8 md:grid-cols-2">{themes.map(t=><div key={t} className="border-t border-line pt-8 serif text-3xl md:text-4xl">{t}</div>)}</div>
      <p className="body-large mt-16 max-w-3xl">The environments changed across industries, platforms, and business contexts — but the underlying challenge remained surprisingly similar: designing systems that scale without creating operational chaos.</p>
    </div></section>
    <section className="section"><div className="container">
      <div className="label mb-12">How I Operate</div>
      <div className="grid gap-8 md:grid-cols-4">{principles.map(p=><div key={p} className="border-t border-line pt-8 serif text-3xl">{p}</div>)}</div>
      <p className="body-large mt-16 max-w-3xl">I prefer environments where thinking is clear, execution is intentional, and systems are designed to reduce friction rather than amplify noise.</p>
    </div></section>
    <StatementSection headline="Good systems exist everywhere once you start noticing them." copy="Outside of systems and product work, I am deeply interested in observing how environments shape behavior — whether through design, cities, technology, architecture, or operational systems in everyday life." />
    <CTASection headline="Complexity becomes manageable when systems become intentional." copy="The most effective operational environments rarely feel chaotic from the inside." primary={{label:'Start a Strategic Conversation', href:'/contact'}} secondary={{label:'View Insights', href:'/insights'}} />
  </PageWrapper>;
}
