import PageWrapper from '@/components/layout/PageWrapper';
import EditorialHero from '@/components/sections/EditorialHero';
import StatementSection from '@/components/sections/StatementSection';
import CTASection from '@/components/sections/CTASection';
import ContactForm from '@/components/forms/ContactForm';
import { siteConfig } from '@/lib/site-config';

export default function Contact() {
  return <PageWrapper>
    <EditorialHero label="Contact" headline="The best operational conversations usually begin long before systems break." copy="Whether you are navigating AI transition, operational complexity, workflow fragmentation, or execution challenges — thoughtful systems design creates leverage quietly over time." primary={{label:'Start a Strategic Conversation', href:'#contact-form'}} secondary={{label:'View Approach', href:'/approach'}} />
    <StatementSection headline="Good operational systems are rarely accidental." copy="Most organizations eventually reach moments where complexity begins slowing clarity, coordination, and execution. Those moments are often where the right systems thinking creates the highest leverage." closing="Thoughtful systems compound quietly." />
    <section className="section"><div className="container grid gap-8 md:grid-cols-3">
      <a className="editorial-card p-8" href={`mailto:${siteConfig.email}`}><div className="label">Email</div><div className="serif mt-16 text-3xl">{siteConfig.email}</div></a>
      <a className="editorial-card p-8" href={siteConfig.linkedin} target="_blank"><div className="label">LinkedIn</div><div className="serif mt-16 text-3xl">Connect</div></a>
      <div className="editorial-card p-8"><div className="label">Timezone</div><div className="serif mt-16 text-3xl">IST / Remote</div></div>
    </div></section>
    <section id="contact-form" className="section"><div className="container text-center">
      <h2 className="display h2 mb-14">Begin Conversation</h2>
      <ContactForm />
    </div></section>
    <CTASection headline="Clarity scales better than intensity." copy="The strongest operational environments are usually designed intentionally long before they are needed." primary={{label:'Return Home', href:'/'}} secondary={{label:'Explore Insights', href:'/insights'}} />
  </PageWrapper>;
}
