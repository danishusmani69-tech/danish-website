import PageWrapper from '@/components/layout/PageWrapper';
import EditorialHero from '@/components/sections/EditorialHero';
import StatementSection from '@/components/sections/StatementSection';
import ExecutionBlock from '@/components/sections/ExecutionBlock';
import CTASection from '@/components/sections/CTASection';

export default function Execution() {
  return <PageWrapper>
    <EditorialHero label="Execution" headline="Execution is not about shipping faster. It is about building systems that continue scaling under complexity." copy="Across AI systems, enterprise products, workflow transformation, and operational architecture, the focus has consistently been the same — reducing friction while improving clarity, coordination, and scalability." primary={{label:'Start a Strategic Conversation', href:'/contact'}} secondary={{label:'Explore Approach', href:'/approach'}} />
    <StatementSection headline="Operational maturity is built through systems, not intensity." copy="The strongest execution environments are not the loudest or busiest. They are the ones where workflows, decision-making, communication, and visibility move together with minimal friction." />
    <section className="section"><div className="container space-y-8">
      <ExecutionBlock number="01" title="Agentic Workflow Systems" copy="Co-built orchestration environments enabling structured multi-step execution, visibility layers, validation checkpoints, and safe operational automation." />
      <ExecutionBlock number="02" title="Enterprise Product Scaling" metric="100+" copy="Scaled enterprise SaaS products across complex operational environments while aligning execution with business outcomes and customer adoption." />
      <ExecutionBlock number="03" title="Operational Transformation" metric="100%" copy="Led operational and organizational transformation initiatives focused on execution clarity, scalable coordination, and measurable business impact." />
    </div></section>
    <section className="section"><div className="container grid gap-10 md:grid-cols-3">
      {['Reduced operational friction','Improved execution visibility','Scalable workflow coordination'].map((o)=><div key={o} className="border-t border-line pt-8 serif text-3xl md:text-4xl">{o}</div>)}
    </div></section>
    <StatementSection headline="Execution environments become stronger when systems are designed intentionally instead of growing reactively." copy="Applied across AI workflow systems, operational architecture, product strategy, enterprise delivery, execution systems, and workflow modernization." />
    <CTASection headline="Well-designed systems create momentum quietly." copy="The most effective operational environments are often the least chaotic." primary={{label:'Start a Strategic Conversation', href:'/contact'}} secondary={{label:'View Insights', href:'/insights'}} />
  </PageWrapper>;
}
