import PageWrapper from '@/components/layout/PageWrapper';
import EditorialHero from '@/components/sections/EditorialHero';
import StatementSection from '@/components/sections/StatementSection';
import CTASection from '@/components/sections/CTASection';

export default function Approach() {
  const flow = ['Observe','Diagnose','Design','Operationalize','Scale'];
  return <PageWrapper>
    <EditorialHero label="Approach" headline="Complex systems rarely fail because of lack of effort. They fail because complexity compounds faster than clarity." copy="I approach operational design through systems thinking — identifying friction, simplifying coordination, and creating environments where execution scales with less operational overhead." primary={{label:'Explore Execution', href:'/execution'}} />
    <StatementSection headline="Most organizations do not suffer from lack of tools. They suffer from fragmented operational systems." copy="As companies scale, workflows, communication, decision-making, delivery, and knowledge structures begin drifting apart. AI amplifies this problem when systems are unclear." />
    <section className="section"><div className="container">
      <div className="mb-12 label">Operational Flow</div>
      <div className="grid gap-6 md:grid-cols-5">{flow.map((item,i)=><div className="border-t border-line pt-7" key={item}><div className="text-gold">0{i+1}</div><div className="serif mt-8 text-3xl">{item}</div></div>)}</div>
      <p className="body-large mt-16 max-w-2xl">The objective is not complexity. The objective is operational leverage.</p>
    </div></section>
    <StatementSection headline="AI alone does not create intelligent organizations." copy="Intelligence emerges when workflows, systems, people, and execution environments move together with clarity." closing="Good operational systems reduce friction. Great systems create leverage." />
    <section className="section"><div className="container grid gap-10 md:grid-cols-3">
      {['Reduced operational friction','Faster execution environments','Clearer organizational visibility'].map((o)=><div key={o} className="border-t border-line pt-8 serif text-3xl md:text-4xl">{o}</div>)}
    </div></section>
    <CTASection headline="Complexity compounds quietly. So does clarity." copy="Well-designed systems create momentum long before organizations realize it." primary={{label:'Start a Strategic Conversation', href:'/contact'}} secondary={{label:'View Insights', href:'/insights'}} />
  </PageWrapper>;
}
